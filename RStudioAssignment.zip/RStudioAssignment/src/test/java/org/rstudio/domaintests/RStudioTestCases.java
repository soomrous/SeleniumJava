package org.rstudio.domaintests;

import org.openqa.selenium.By;
import org.rstudio.domainclasses.objectlibrary.HomePage;
import org.rstudio.testsupport.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class RStudioTestCases extends BaseTest {
    HomePage homePage = new HomePage();

    @Test(priority = 1)
    public void createSpace() {
        homePage.clickNewSpaceButton(webDriver);
        homePage.enterSpaceName(webDriver, properties.getProperty("spaceName"));
        homePage.clickCreateButton(webDriver);
    }

    @Test(priority = 2)
    public void createProjectWithinSpace() {
        Assert.assertEquals("RStudioAssignment", homePage.getCreatedSpaceText(webDriver));
        homePage.clickOnCreatedSpace(webDriver);
        homePage.clickNewProjectDropdown(webDriver);
        homePage.selectNewRStudioProjectOption(webDriver);
        webDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        webDriver.switchTo().frame(webDriver.findElement(By.id("contentIFrame")));
        Assert.assertEquals("File", homePage.getRStudioProjectFileMenu(webDriver));
        webDriver.switchTo().defaultContent();
    }

}