package org.rstudio.testsupport;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.rstudio.domainclasses.objectlibrary.HomePage;
import org.rstudio.domainclasses.objectlibrary.LoginPage;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class BaseTest {
    protected Logger logger;
    protected WebDriver webDriver;
    protected Properties properties;
    String testName;
    String testSuiteName;

    LoginPage loginPage = new LoginPage();
    HomePage homePage = new HomePage();

    /**
     * This method runs before any test methods, and it loads the config.properties file, initiate the webDriver and Logger
     *
     * @param iTestContext ITestContext
     */
    @BeforeTest
    public void loadTestData(ITestContext iTestContext) {
        String testcaseName = iTestContext.getName();
        logger = Logger.getLogger(testcaseName);
        logger.info("Running TestCase: " + testcaseName);
        properties = ReadProperties.readPropertiesFile("config.properties");
        String browserType = properties.getProperty("browserType");

        new InitiateBrowserDrivers(browserType, logger);
        webDriver = InitiateBrowserDrivers.initiateWebDriver();

        webDriver.manage().window().maximize();
        webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        this.testName = testcaseName;
        this.testSuiteName = iTestContext.getSuite().getName();

        login();
    }


    /**
     * This method runs after all test methods have run, and it quits the webDriver
     */
    @AfterTest
    public void closeWebDriver() {
        logout();
        webDriver.quit();
    }

    public void login() {
        logger.info("Trying to Login to RStudio Application");
        webDriver.get(properties.getProperty("url"));
        loginPage.clickLoginLink(webDriver);
        loginPage.enterUserName(webDriver, properties.getProperty("userName"));
        loginPage.clickContinueButton(webDriver);
        loginPage.enterPassword(webDriver, properties.getProperty("password"));
        loginPage.clickLoginButton(webDriver);
        logger.info("Successfully Logged into RStudio Application");
    }

    public void logout() {
        logger.info("Trying to Logout from RStudio Application");
        homePage.clickOnLoggedInUser(webDriver);
        homePage.clickLogoutButton(webDriver);
        Assert.assertEquals("Log In", loginPage.getLoginLinkText(webDriver));
        logger.info("Successfully Logged out from RStudio Application");
    }

}
