package org.rstudio.testsupport;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class InitiateBrowserDrivers {
    static final Logger logger = Logger.getLogger(InitiateBrowserDrivers.class);
    static WebDriver webDriver;
    private String browserType;
    private Logger log;

    /**
     * This constructor will take browser and Logger as parameters and calls initiateWebDriver() method
     *
     * @param browserType Type of Browser, Passed from BeforeMethod
     * @param logger Log4j Logger
     */
    InitiateBrowserDrivers(String browserType, Logger logger) {
        this.browserType = browserType.toLowerCase();
        this.log = logger;
    }

    /**
     * This method initializes the webDriver
     *
     * @return WebDriver
     */
    static WebDriver initiateWebDriver() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        webDriver = new ChromeDriver();
        logger.info("Chrome Driver Started Successfully");
        return webDriver;
    }

}
