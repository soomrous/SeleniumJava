package org.rstudio.testsupport;

import org.apache.log4j.Logger;

import java.util.Base64;

public class Encryption {
    static final Logger logger = Logger.getLogger(Encryption.class);

    /**
     * Encrypts the User's Password using the Base64 format
     *
     * @param stringToEncrypt String (password) to be encrypted
     * @return Encrypted Base64 String (password)
     */
    public static String encryptString(String stringToEncrypt) {
        String encryptedString = Base64.getEncoder().encodeToString(stringToEncrypt.getBytes());
        logger.info("String encrypted successfully");
        return encryptedString;
    }

    /**
     * Decrypts the User's Password using the Base64 format
     *
     * @param stringToDecrypt String (password) to be decrypted
     * @return Decrypted Base64 String (password)
     */
    public static String decryptString(String stringToDecrypt) {
        byte[] decryptedString = Base64.getDecoder().decode(stringToDecrypt);
        logger.info("String decrypted successfully");
        return new String(decryptedString);
    }

}
