package org.rstudio.testsupport;

import org.apache.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadProperties {
    static final Logger logger = Logger.getLogger(ReadProperties.class);

    /**
     * This function reads the properties file based on the file name provided as a parameter
     *
     * @param fileName config or database properties file
     * @return properties object
     */
    public static Properties readPropertiesFile(String fileName) {
        FileInputStream fileInputStream;
        Properties properties = null;

        try {
            properties = new Properties();
            fileInputStream = new FileInputStream("src/main/resources/" + fileName);

            properties.load(fileInputStream);
            logger.info("Properties file: " + fileName + " has been configured successfully");

            fileInputStream.close();

        } catch (IOException e) {
            logger.error("Error Reading Properties file: " + fileName + ": ", e);
        }

        return properties;
    }

}
