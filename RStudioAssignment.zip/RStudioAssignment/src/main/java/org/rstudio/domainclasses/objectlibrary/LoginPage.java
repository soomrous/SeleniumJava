package org.rstudio.domainclasses.objectlibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.rstudio.testsupport.Encryption;

public class LoginPage {
    By loginLink = By.cssSelector("#currentUser > div > div > a:nth-child(1)");
    By userNameField = By.name("email");
    By continueButton = By.xpath("(//button[@type='submit'])[1]");
    By passwordField = By.name("password");
    By loginButton = By.cssSelector("button[type='submit']");


    //Click the Login Link on RStudio Home page
    public void clickLoginLink(WebDriver webDriver) {
        webDriver.findElement(loginLink).click();
    }

    //Enter the Email on RStudio Login page
    public void enterUserName(WebDriver webDriver, String userName) {
        webDriver.findElement(userNameField).sendKeys(userName);
    }

    //Click the Continue Button after entering the UserName
    public void clickContinueButton(WebDriver webDriver) {
        webDriver.findElement(continueButton).click();
    }

    //Enter the Password on RStudio Login page
    public void enterPassword(WebDriver webDriver, String password) {
        String decryptedPassword = Encryption.decryptString(password);
        webDriver.findElement(passwordField).sendKeys(decryptedPassword);
    }

    //Click the Login Button after entering the Password
    public void clickLoginButton(WebDriver webDriver) {
        webDriver.findElement(loginButton).click();
    }

    //Get the LoginLink text name from RStudio Home page
    public String getLoginLinkText(WebDriver webDriver) {
        return webDriver.findElement(loginLink).getText();
    }
}