package org.rstudio.domainclasses.objectlibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    By newSpaceButton = By.cssSelector("button[class='menuItem newSpace']");
    By spaceNameText = By.id("name");
    By createButton = By.cssSelector("button[type='submit']");
    By loggedInUser = By.cssSelector("div[id='currentUser'] div[class='userName'] div");
    By logoutButton = By.cssSelector(".menuItem.logout");
    By createdSpaceText = By.className("spaceNameWithOwner");
    By newProjectDropdown = By.xpath("//span[normalize-space()='New Project']");
    By rStudioProjectDropdownOption = By.cssSelector("button[title='New RStudio Project'] span[class='actionTitle']");
    By rStudioProjectFileMenu = By.cssSelector("#rstudio_label_file_menu");

    //Click the New Space Button on RStudio Home page
    public void clickNewSpaceButton(WebDriver webDriver) {
        webDriver.findElement(newSpaceButton).click();
    }

    //Enter the Space Name on RStudio Home page
    public void enterSpaceName(WebDriver webDriver, String spaceName) {
        webDriver.findElement(spaceNameText).sendKeys(spaceName);
    }

    //Click the Create Button After entering the Space Name
    public void clickCreateButton(WebDriver webDriver) {
        webDriver.findElement(createButton).click();
    }

    //Click on User Profile from Top Right on RStudio Home Page
    public void clickOnLoggedInUser(WebDriver webDriver) {
        webDriver.findElement(loggedInUser).click();
    }

    //Click on Logout after clicking on User Profile
    public void clickLogoutButton(WebDriver webDriver) {
        webDriver.findElement(logoutButton).click();
    }

    //Click on created Space from Left Nav Menu
    public void clickOnCreatedSpace(WebDriver webDriver) {
        webDriver.findElement(createdSpaceText).click();
    }

    //Get the text from Created Space
    public String getCreatedSpaceText(WebDriver webDriver) {
        return webDriver.findElement(createdSpaceText).getText();
    }

    //Click on New Project menu dropdown after clicking on a created Space
    public void clickNewProjectDropdown(WebDriver webDriver) {
        webDriver.findElement(newProjectDropdown).click();
    }

    //Select on New RStudio Project option from New Project dropdown
    public void selectNewRStudioProjectOption(WebDriver webDriver) {
        webDriver.findElement(rStudioProjectDropdownOption).click();
    }

    //Get the text from the newly created RStudio Project
    public String getRStudioProjectFileMenu(WebDriver webDriver) {
        return webDriver.findElement(rStudioProjectFileMenu).getText();
    }

}